ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "357 30"
ENT.Author = ""
ENT.Spawnable = true
ENT.AdminSpawnable = false 
ENT.Category = "[Ammo box]"