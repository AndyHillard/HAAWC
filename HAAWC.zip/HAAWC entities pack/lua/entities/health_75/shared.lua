DEFINE_BASECLASS( "base_gmodentity" )

ENT.PrintName		= "Health 75 LVL"
ENT.Author		    = ""
ENT.Information		= "Health give you... health!"
ENT.Category		= "[Health vial]"

ENT.Editable		= false
ENT.Spawnable		= true
ENT.AdminOnly		= false