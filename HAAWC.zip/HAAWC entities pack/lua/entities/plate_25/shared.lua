DEFINE_BASECLASS( "base_gmodentity" )

ENT.PrintName		= "Armor 25 LVL"
ENT.Author		    = ""
ENT.Information		= "Armor plate give you armor lvl"
ENT.Category		= "[Armor plates]"

ENT.Editable		= false
ENT.Spawnable		= true
ENT.AdminOnly		= false