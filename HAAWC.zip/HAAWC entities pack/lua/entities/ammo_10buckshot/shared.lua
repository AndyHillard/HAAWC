ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Buckshot 10"
ENT.Author = ""
ENT.Spawnable = true
ENT.AdminSpawnable = false 
ENT.Category = "[Ammo box]"