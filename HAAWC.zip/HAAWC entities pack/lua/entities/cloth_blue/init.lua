AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include('shared.lua')

function ENT:Initialize()
	self.Entity:SetModel("models/props_junk/cardboard_box001a.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	
	local phys = self.Entity:GetPhysicsObject()
	self.nodupe = true
	self.ShareGravgun = true

	if phys and phys:IsValid() then phys:Wake() end
end

function ENT:Use(plyUse)
    if plyUse:IsPlayer() then
		self:Remove()
		self:EmitSound("physics/body/body_medium_strain3.wav", 100);
	    plyUse:SendLua("local tab = {Color(255,255,255), [[You wore]], Color(0,0,136), [[ blue]], Color(255,255,255), [[ clothes.]]} chat.AddText(unpack(tab))");
		plyUse:SetModel( "models/player/group01/male_0"..math.random(1,9)..".mdl" )
		plyUse:SetPlayerColor( Vector( 0, 0, 0.5 ) )
        end
end

function ENT:OnRemove()
	self:Remove()
end