AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include('shared.lua')

function ENT:Initialize()
	self.Entity:SetModel("models/props_lab/box01a.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	
	local phys = self.Entity:GetPhysicsObject()
	self.nodupe = true
	self.ShareGravgun = true

	if phys and phys:IsValid() then phys:Wake() end
end

function ENT:Use(plyUse)
	if (plyUse:Health() < plyUse:GetMaxHealth()) then
		self:Remove()
		plyUse:SetHealth( math.Clamp( plyUse:Health() + 50, 0, plyUse:GetMaxHealth() ) )
    	self:EmitSound("physics/cardboard/cardboard_box_strain3.wav", 100);
	    plyUse:SendLua("local tab = {Color(255,255,255), [[You used health vial,]], Color(255,127,127), [[ add 50 HP]], Color(255,255,255), [[.]]} chat.AddText(unpack(tab))");
	end
end

function ENT:OnRemove()
	self:Remove()
end