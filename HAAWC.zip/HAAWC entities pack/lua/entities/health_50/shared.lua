DEFINE_BASECLASS( "base_gmodentity" )

ENT.PrintName		= "Health 50 LVL"
ENT.Author		    = ""
ENT.Information		= "Health give you... health!"
ENT.Category		= "[Health vial]"

ENT.Editable		= false
ENT.Spawnable		= true
ENT.AdminOnly		= false