AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include('shared.lua')

function ENT:Initialize()
	self.Entity:SetModel("models/props_junk/cardboard_box004a.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	
	local phys = self.Entity:GetPhysicsObject()
	self.nodupe = true
	self.ShareGravgun = true

	if phys and phys:IsValid() then phys:Wake() end
end

function ENT:Use(plyUse)
	if (plyUse:Armor() < 50) then
		self:Remove()
		plyUse:SetArmor(50)
		self:EmitSound("physics/body/body_medium_strain3.wav", 100);
	    plyUse:SendLua("local tab = {Color(255,255,255), [[You used armor plate,]], Color(0,161,255), [[ set 50 armor]], Color(255,255,255), [[.]]} chat.AddText(unpack(tab))");
		--plyUse:SetModel( "" )
		--plyUse:SetSkin(0,0)
	end
end

function ENT:OnRemove()
	self:Remove()
end