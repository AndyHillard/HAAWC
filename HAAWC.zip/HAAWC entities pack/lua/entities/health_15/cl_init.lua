include('shared.lua')

ENT.RenderGroup = RENDERGROUP_OPAQUE

surface.CreateFont("healthvial", {
    size = 13,
    weight = 0,
    antialias = false,
    shadow = false,
    font = "Arial"})
	
function ENT:Draw()
	self:DrawModel()

	local Pos = self:GetPos()
	local Ang = self:GetAngles()
	
	Ang:RotateAroundAxis(Ang:Forward(), 90)
	Ang:RotateAroundAxis(Ang:Right(), 270)
	
	local txt1 = "Health"
	local txt2 = "Vial"
	local txt3 = "15"
	
	surface.SetFont("DermaLarge")
	local TextWidthLabel = surface.GetTextSize(txt1)
	local TextWidthLabel = surface.GetTextSize(txt2)
	local TextWidthLabel = surface.GetTextSize(txt3)
	
	cam.Start3D2D(Pos + Ang:Up() * 3.1 - Ang:Right() * -1.4, Ang, 0.11)
		draw.WordBox(1, -TextWidthLabel*0.06, -25, txt1, "healthvial", Color(0, 100, 0, 200), Color(255,255,255,255))
	    draw.WordBox(1, -TextWidthLabel*-0.15, -10, txt2, "healthvial", Color(0, 100, 0, 200), Color(255,255,255,255))
		draw.WordBox(1, -TextWidthLabel*1.25, 1, txt3, "healthvial", Color(100, 0, 0, 200), Color(255,255,255,255))
	cam.End3D2D()
end