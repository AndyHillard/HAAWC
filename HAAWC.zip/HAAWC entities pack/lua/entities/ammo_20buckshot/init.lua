AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/Items/BoxSRounds.mdl") 
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	
	local phys = self.Entity:GetPhysicsObject()
	self.nodupe = true
	self.ShareGravgun = true
end

function ENT:Use(plyUse, caller)
	if plyUse:IsPlayer() then
		plyUse:GiveAmmo(20, "buckshot")
		self:Remove()
	    self:EmitSound("physics/cardboard/cardboard_box_break3.wav", 100);
	    plyUse:SendLua("local tab = {Color(255,255,255), [[You used ammo box,]], Color(191,255,127), [[ add 20 buckshot]], Color(255,255,255), [[.]]} chat.AddText(unpack(tab))");
	end
end

function ENT:OnRemove()
	return false
end 