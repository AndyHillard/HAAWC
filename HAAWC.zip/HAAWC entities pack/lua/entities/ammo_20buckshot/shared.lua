ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Buckshot 20"
ENT.Author = ""
ENT.Spawnable = true
ENT.AdminSpawnable = false 
ENT.Category = "[Ammo box]"