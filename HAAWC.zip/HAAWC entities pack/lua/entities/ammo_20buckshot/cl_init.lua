include('shared.lua')

ENT.RenderGroup = RENDERGROUP_OPAQUE

surface.CreateFont("ammobox", {
    size = 24,
    weight = 0,
    antialias = false,
    shadow = false,
    font = "Arial"})
	
function ENT:Draw()
	self:DrawModel()

	local Pos = self:GetPos()
	local Ang = self:GetAngles()
	
	Ang:RotateAroundAxis(Ang:Forward(), 90)
	Ang:RotateAroundAxis(Ang:Right(), 270)
	
	local txt1 = "Ammo"
	local txt2 = "Box"
	local txt3 = "20"
	local txt4 = "Buckshot"
	
	surface.SetFont("DermaLarge")
	local TextWidthLabel = surface.GetTextSize(txt1)
	local TextWidthLabel = surface.GetTextSize(txt2)
	local TextWidthLabel = surface.GetTextSize(txt3)
	local TextWidthLabel = surface.GetTextSize(txt4)
	
	cam.Start3D2D(Pos + Ang:Up() * 3.1 - Ang:Right() * 8, Ang, 0.11)
		draw.WordBox(1, -TextWidthLabel*0.27, -25, txt1, "ammobox", Color(100, 0, 0, 200), Color(255,255,255,255))
	    draw.WordBox(1, -TextWidthLabel*0.17, 1, txt2, "ammobox", Color(100, 0, 0, 200), Color(255,255,255,255))
		draw.WordBox(1, -TextWidthLabel*0.7, 45, txt3, "ammobox", Color(0, 0, 100, 200), Color(255,255,255,255))
	    draw.WordBox(1, -TextWidthLabel*0.08, 45, txt4, "ammobox", Color(100, 100, 0, 200), Color(255,255,255,255))
	cam.End3D2D()
end