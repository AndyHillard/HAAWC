DEFINE_BASECLASS( "base_gmodentity" )

ENT.PrintName		= "Green cloth"
ENT.Author		    = ""
ENT.Information		= "Set you model and color"
ENT.Category		= "[Cloth]"

ENT.Editable		= false
ENT.Spawnable		= true
ENT.AdminOnly		= false