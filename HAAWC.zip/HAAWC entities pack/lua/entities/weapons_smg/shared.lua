DEFINE_BASECLASS( "base_gmodentity" )

ENT.PrintName		= "SMG"
ENT.Author		    = ""
ENT.Information		= "Give you weapon!"
ENT.Category		= "[Weapon box]"

ENT.Editable		= false
ENT.Spawnable		= true
ENT.AdminOnly		= false