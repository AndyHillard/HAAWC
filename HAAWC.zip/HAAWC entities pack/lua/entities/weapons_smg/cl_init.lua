include('shared.lua')

ENT.RenderGroup = RENDERGROUP_OPAQUE

surface.CreateFont("clothes", {
    size = 50,
    weight = 0,
    antialias = false,
    shadow = false,
    font = "Arial"})
	
function ENT:Draw()
	self:DrawModel()

	local Pos = self:GetPos()
	local Ang = self:GetAngles()
	
	Ang:RotateAroundAxis(Ang:Forward(), 0)
	Ang:RotateAroundAxis(Ang:Right(), 0)
	Ang:RotateAroundAxis(Ang:Up(), 90)
	
	local txt1 = "SMG"
	
	surface.SetFont("DermaLarge")
	local TextWidthLabel = surface.GetTextSize(txt1)
	
	cam.Start3D2D(Pos + Ang:Up() * 9 - Ang:Right() * 2, Ang, 0.11)
		draw.WordBox(1, -TextWidthLabel*0.8, -10, txt1, "clothes", Color(0, 100, 0, 200), Color(255,255,255,255))
	cam.End3D2D()
end